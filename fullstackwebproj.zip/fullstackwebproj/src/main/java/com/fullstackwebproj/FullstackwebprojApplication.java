package com.fullstackwebproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullstackwebprojApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullstackwebprojApplication.class, args);
	}

}
