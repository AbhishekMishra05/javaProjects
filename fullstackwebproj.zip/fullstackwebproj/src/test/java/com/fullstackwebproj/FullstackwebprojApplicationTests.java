package com.fullstackwebproj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullstackwebprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
